<?php

class Autoloader_ruins {

    protected string $prefix;

    protected string $path;

    function __construct(string $pr, string $pa){
        $this->prefix = $pr;
        $this->path = $pa;
    }

    public function loadClass(string $className){
        $classPath = str_replace($this->prefix, $this->path, $className);
        $classPath = str_replace('\\', DIRECTORY_SEPARATOR, $classPath);
        require_once $classPath.".php";
    
    }

    public function register(){
        spl_autoload_register([$this,'loadclass']);
    }
}