<?php

require_once "vendor\autoload.php";

session_start();

if(isset($_REQUEST['action'])){
    $d = new \spautify\Dispatcher($_REQUEST['action']);
} else {
    $d = new \spautify\Dispatcher("default");
}

if(!isset($_SESSION['user'])){
    $t = ["",null];
    $_SESSION['user'] = serialize($t);
}

//lier le fichier de configuration à notre DeefyRepository
\spautify\repository\SpautifyRepository::setConfig('conf.ini');

$d->run();


