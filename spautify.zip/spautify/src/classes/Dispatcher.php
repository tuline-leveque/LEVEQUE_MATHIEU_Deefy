<?php

namespace spautify;

use spautify\actions as A;

class Dispatcher {

    private ?string $action;

    function __construct(?string $action){
        $this->action = $action;
    }

    public function renderPage($html){
        echo $html;
    }

    public function run(){
        $bool = \spautify\auth\Authz::checkRole(100);
        $html = "";
        $html .= '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Spautify</title>
            <link rel="stylesheet" href="style.css">
        </head>
        <body>';
        $html.= "<div class = 'admin{$bool}' id = 'banner'>
        <h1 id = 'title'>Spautify</h1>";

        $user = \spautify\auth\AuthnProvider::getSignedInUser();
        if ($user == "") {
            $html .= "<b id='usr'>Connecté en tant qu'invité</b></br></br>";
            $html .= '<a id="connLnk" href="?action=sign-in"> Connexion </a></br>';
        } else {
            $emailUser = unserialize($_SESSION['user'])[0];
            $html .= "<b id='usr' class = 'admin{$bool}'>Connecté en tant que {$emailUser}</b></br></br>";
            $html .= '<a id="connLnk" href="?action=disconnect"> Déconnexion </a></br>';
        }

        $html .= "</div><div id = 'content'><div id='choices'>";
        
        switch($this->action){
            case 'default':
                $action = new A\DefaultAction();
                $html .= $action->execute();
                break;
            case 'add-playlist':
                $action = new A\AddPlaylistAction();
                $html .= $action->execute();
                break;
            case 'add-track':
                $action = new A\AddPodcastTrackAction();
                $html .= $action->execute();
                break;
            case 'display-playlist':
                $action = new A\DisplayPlaylistAction();
                $html .= $action->execute();
                break;
            case 'add-user':
                $action = new A\AddUserAction();
                $html .= $action->execute();
                break;
            case 'sign-in':
                $action = new A\SigninAction();
                $html .= $action->execute();
                break;
            case 'select-playlist':
                $action = new A\SelectPlayListAction();
                $html .= $action->execute();
                break;
            case 'disconnect':
                $action = new A\DisconnectAction();
                $html .= $action->execute();
                break;
            default:
                $html .= "<a>erreur sur la requête</a>";
                break;

        }
        $html .= '</div></div></body>
        </html>';
        $this->renderPage($html);
    }
}