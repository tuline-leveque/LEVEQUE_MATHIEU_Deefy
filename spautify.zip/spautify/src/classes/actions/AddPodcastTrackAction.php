<?php

namespace spautify\actions;
use \spautify\audio as AD;


class AddPodcastTrackAction extends Action{
    public function execute() : string {
        $bool = \spautify\auth\Authz::checkRole(100);
        $html = "";
        if(!isset($_SESSION['playlist'])){
            $html.= "<b>Pas de playlist sélectionnée</b>";
            $html .= "</br></br><a class='adminc{$bool}' id='choice' href='?action=default'> Retourner au menu </a>";
            return $html;

        } else {
            $pl = unserialize($_SESSION['playlist']);
            if(! $pl instanceof AD\AudioList){
                return "<b>pas de playlist sélectionnée</b>";
            }
            if($_SERVER["REQUEST_METHOD"] == 'GET'){
                $html .= "<form method = 'POST' action ='?action=add-track'></br>";
                $html .= "<label for='artiste'>Artiste :</label></br>";
                $html .= "<input type='text' id='artiste' name='artiste'></br>";
                $html .= "<label for='titre'>Titre :</label></br>";
                $html .= "<input type='text' id='titre' name='titre'></br>";
                $html .= "<label for='anneee'>Annee :</label></br>";
                $html .= "<input type='number' id='annee' name='annee'></br>";
                $html .= "<label for='genre'>Genre :</label></br>";
                $html .= "<input type='text' id='genre' name='genre'></br></br>";
                $html .= "<button type = 'submit'>créer</button></form></br>";
                $html .= '<a href="?action=add-track">Ajouter encore une piste</a>';
                $html .= "</br></br><a class ='adminc{$bool}'id='choice' href='?action=default'> Retourner au menu </a>";
            } else {
                
                $tr = new AD\AlbumTrack($_POST['titre'], $_POST['artiste'], $_POST['annee'], $_POST['genre'],50,"c:/truc", 1, "album"); //faut mettre autre chose après
                $pl->add($tr);
                $bd = \spautify\repository\SpautifyRepository::getInstance();
                $bd->saveTrack($tr);
                $bd->linkTrackToPlaylist($pl,$tr);
                $html = "<b>Titre ajouté avec succès</b><br>";
                $html .= "</br></br><a class ='adminc{$bool}'id='choice' href='?action=default'> Retourner au menu </a>";
            }

            $_SESSION['playlist'] = serialize($pl);
           
        }
        return $html;
    }
}