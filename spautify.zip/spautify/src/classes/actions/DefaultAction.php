<?php 

namespace spautify\actions;

class DefaultAction extends Action{
    public function execute() : string {
        $bool = \spautify\auth\Authz::checkRole(100);
        $html = "";

        $html .= "<a class = 'adminc{$bool}' id = 'choice' href='?action=add-track'> ajouter une musique </a></br></br></br>";
        $html .= "<a class = 'adminc{$bool}' id = 'choice' href='?action=add-playlist'> créer une playlist </a></br></br></br>";
        $html .= "<a class = 'adminc{$bool}' id = 'choice' href='?action=display-playlist'> afficher une playlist </a></br></br></br>";
        $html .= "<a class = 'adminc{$bool}' id = 'choice' href='?action=select-playlist'> afficher toutes les playlists </a></br></br></br>";
        $html .= "<a class = 'adminc{$bool}' id = 'choice' href='?action=add-user'> créer utilisateur </a></br>";

        return $html;
    }
}