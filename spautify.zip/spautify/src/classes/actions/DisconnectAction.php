<?php

namespace spautify\actions;

class DisconnectAction extends Action {
    public function execute() : string {
        $bool = \spautify\auth\Authz::checkRole(100);
        $html = "<a>Vous avez été déconnecté de spautify</a></br></br>";
        $html .= "<a class='adminc{$bool}' id='choice' href ='?action=default'>Retour au menu principal</a>";

        $arr = unserialize($_SESSION['user']);
        $arr[0] = "";
        $_SESSION['user'] = serialize($arr);
        unset($_SESSION['playlist']);

        return $html;
    }
}