<?php

namespace spautify\actions;
use \spautify\audio as AD;
use \spautify\render as RD;

class DisplayPlaylistAction extends Action{
    public function execute() : string {
        $bool = \spautify\auth\Authz::checkRole(100);
        $html = "";
        if( ! isset($_SESSION['playlist'])){
            $html .= "<b>Pas de playlist en session</b>";
        } else {
            $pl = unserialize($_SESSION['playlist']);
            $r = new RD\AudioListRenderer($pl);
            $html .= $r->render(RD\Renderer::COMPACT);
        }
        $html .= "</br></br><a class='adminc{$bool}' id='choice' href='?action=default'> Retourner au menu </a>";
        return $html;
    }
}