<?php

namespace spautify\audio;

class AlbumTrack extends AudioTrack{

    public string $album;
    public $nbTrack;
    public $year;

    public function __construct(string $title, string $artist, int $year, string $genre, int $durationSec, string $filePath, int $nbt, string $album){
        parent::__construct($title, $artist, $genre, $durationSec, $filePath);
        $this->album = $album;
        $this->nbTrack = $nbt;
        $this->year = $year;
    }

    public function setArtist(string $a) : void {
        $this->artist = $a;
    }

    public function setGenre(string $g) : void {
        $this->genre = $g;
    }

    public function setDuration(int $s) : void {
        if($s >= 0){
            $this->durationSec = $s;
        }
       
    }

    /**
     * @throws \Exception
     */
    public function __get(string $attr) : mixed{
        if(property_exists($this,$attr)){
            return $this->$attr;
        } else {
            throw new \Exception("attribut $attr inexistant");
        }
    }
}