<?php   

namespace spautify\audio;

abstract class AudioTrack {

    public string $title = "";
    public string $artist = "";
    public string $genre = "";
    public $durationSec = 0;
    public string $filePath = "";

    public function __construct(string $title, string $artist, string $genre, $durationSec = 0, string $filePath){
        $this->title = $title;
        $this->artist = $artist;
        $this->genre = $genre;
        $this->durationSec = (int)($durationSec);
        $this->filePath = $filePath;
    }

    public function setArtist(string $a) : void {
        $this->artist = $a;
    }

    public function setGenre(string $g) : void {
        $this->genre = $g;
    }

    public function setDuration(int $s) : void {
        if($s >= 0){
            $this->durationSec = $s;
        }
       
    }

    public function __get(string $attr) : mixed{
        if(property_exists($this,$attr)){
            return $this->$attr;
        } else {
            throw new Exception("attribut $attr inexistant");
        }
    }

    function __toString() : string {
        return json_encode(get_object_vars($this));
    }

}