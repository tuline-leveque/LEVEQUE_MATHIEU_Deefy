<?php

namespace spautify\audio;

class PodcastTrack extends AudioTrack{

    private string $year;

    public function __construct(string $title, string $artist, string $year, string $genre, int $durationSec, string $filePath){
        parent::__construct($title, $artist, $genre, $durationSec, $filePath);
        $this->year = $year;
    }

    public function setArtist(string $a) : void {
        $this->artist = $a;
    }

    public function setGenre(string $g) : void {
        $this->genre = $g;
    }

    public function setDuration(int $s) : void {
        if($s >= 0){
            $this->durationSec = $s;
        }
       
    }

    public function __get(string $attr) : mixed{
        if(property_exists($this,$attr)){
            return $this->$attr;
        } else {
            throw new Exception("attribut $attr inexistant");
        }
    }
}