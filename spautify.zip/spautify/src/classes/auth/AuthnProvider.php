<?php

namespace spautify\auth;

use PDO;
use spautify\exception\AuthnException;

class AuthnProvider {

    /**
     * @throws AuthnException
     */
    public static function signin($addr, $mdp){
        $conn = \spautify\repository\SpautifyRepository::getInstance()->getDb();

        $query = $conn->prepare("select passwd from user where email = ? ;");
        $query->bindParam(1,$addr);
        $query->execute();

        $pwd = $query->fetch(PDO::FETCH_ASSOC)["passwd"];

        if (! password_verify($mdp,$pwd)){
            throw new \spautify\exception\AuthnException("identifiant ou mot de passe invalide");
        }
    }

    /**
     * @throws AuthnException
     */
    public static function register($addr, $mdp){
        if (strlen($mdp) < 10 ){
            throw new \spautify\exception\AuthnException("mot de passe trop faible");
        }
        $conn = \spautify\repository\SpautifyRepository::getInstance()->getDb();

        $query = $conn->prepare("select * from user where email = ? ;");
        $query->bindParam(1,$addr);
        $query->execute();

        $res = $query->fetchAll(PDO::FETCH_ASSOC);

        if (sizeof($res) != 0) {
            throw new \spautify\exception\AuthnException("un utilisateur utilise déjà cette adresse");
        }


        $query2 = $conn->prepare("insert into user (email,passwd,role) values (?,?,1)");
        $query2->bindParam(1,$addr);
        $mdp2 = password_hash($mdp,PASSWORD_DEFAULT);
        $query2->bindParam(2,$mdp2);
        $query2->execute();
    }


    public static function getSignedInUser() : string {
        return unserialize($_SESSION['user'])[0];
    }

}