<?php 
namespace spautify\exception;
class AuthnException extends  \Exception{}