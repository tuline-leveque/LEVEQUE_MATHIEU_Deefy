<?php

namespace Exception;

class InvalidPropertyValueException {}