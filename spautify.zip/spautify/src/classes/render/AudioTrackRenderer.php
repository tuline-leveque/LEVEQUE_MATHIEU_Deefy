<?php

namespace spautify\render;

abstract class AudioTrackRenderer implements Renderer{
    protected \spautify\audio\AudioTrack $track;

    public function __construct(\spautify\audio\AudioTrack $a){
        $this->track = $a;
    }

    public function render(string $selector) : string{
        switch( $selector){
            case Renderer::COMPACT:
                return $this->renderShort();
                break;
            case Renderer::LONG:
                return $this->renderFullScreen();
                break;
        }
    }

    protected function renderShort() : string {
        return "";
    }

    protected function renderFullScreen() : string {
        return "";
    }
}