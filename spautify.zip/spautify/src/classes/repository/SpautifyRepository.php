<?php

namespace spautify\repository;

use PDO;

class SpautifyRepository {

    private static SpautifyRepository $sp;
    private static string $CONF;
    private static array $PARAMS;
    private PDO $bd;

    private function __construct(){
        if(!isset($_PARAMS)){
            $this->setConfig("conf.ini");
        }
        $this->bd =  new PDO(self::$PARAMS['driver'].":host=".self::$PARAMS['host']."; dbname=".self::$PARAMS['database']."; charset=utf8", self::$PARAMS['username'],self::$PARAMS['password']);
    }

    public static function setConfig($file){
        self::$CONF = $file;
        self::$PARAMS = parse_ini_file($file);
    }

    public static function getInstance(){
        if(! isset($sp)){
            $sp = new SpautifyRepository();
        }
        return $sp;
    }

    public function getDb(){
        return $this->bd;
    }

    public function getAllPlaylists(){
        if( ! isset($_SESSION['user'])){
            return [];
        }
        if (\spautify\auth\Authz::checkRole(100)){
            $query = $this->bd->prepare("select playlist.id,playlist.nom from playlist;");
        } else {
            $query = $this->bd->prepare("select playlist.id,playlist.nom from playlist inner join user2playlist on playlist.id = user2playlist.id_pl inner join user on user.id = user2playlist.id_user where user.email = ?;");
            $user = \spautify\auth\AuthnProvider::getSignedInUser();
            $emailUser = unserialize($_SESSION['user'])[0];
            $query->bindParam(1,$emailUser);
        }

        
        $query->execute();
        $list = [];
        $cntr = 0;

        while($row = $query->fetch(PDO::FETCH_ASSOC)){
            $list[$cntr] = $row;
            $cntr ++;
        }

        return $list;
    }

    public function savePlaylist($pl){
        if (! $pl instanceof \spautify\audio\AudioList){
            return false;
        }
        $query = $this->bd->prepare("insert into playlist(nom) values(?);");
        $query->bindParam(1,$pl->name);
        $query->execute();
        return true;
    }

    public function saveTrack($tr){
        if (! $tr instanceof \spautify\audio\AudioTrack){
            return false;
        }
        $query = $this->bd->prepare("insert into track(titre, genre, duree, filename, type, artiste_album, titre_album, annee_album, numero_album, auteur_podcast, date_posdcast) values(?,?,?,?,?,?,?,?,?,?,?);");
        $nll = null;
        $a = "A";
        $p = "P";
        $query->bindParam(1,$tr->title);
        $query->bindParam(2,$tr->genre);
        $query->bindParam(3,$tr->durationSec);
        $query->bindParam(4,$tr->filePath);
        if($tr instanceof \spautify\audio\AlbumTrack) {
            $query->bindParam(5,$a);
            $query->bindParam(6,$tr->artist);
            $query->bindParam(7,$tr->album);
            $query->bindParam(8,$tr->year);
            $query->bindParam(9,$tr->nbTrack);
            $query->bindParam(10,$nll);
            $query->bindParam(11,$nll);
        } else {
            
            $query->bindParam(5,$p);
            for($i = 5; $i < 10; $i++){
                $query->bindParam($i,$nll);
            }
            $query->BindParam(10,$tr->auteur);
            $query->BindParam(10,$tr->year);
        }
        $query->execute();
        return true;

    }

    public function linkTrackToPlaylist($pl, $tr){
        if (! $tr instanceof \spautify\audio\AudioTrack && ! $pl instanceof \spautify\audio\PlayList){
            return false;
        }
        $plQuery = $this->bd->prepare("select id from playlist where nom = ?;");
        $plQuery->bindParam(1,$pl->name);
        $plQuery->execute();

        $plId = $plQuery->fetch(PDO::FETCH_ASSOC)["id"];

        $trQuery = $this->bd->prepare("select id from track where titre = ? and duree = ?;");
        $trQuery->bindParam(1,$tr->title);
        $trQuery->bindParam(2,$tr->durationSec);
        $trQuery->execute();

        $trId = $trQuery->fetch(PDO::FETCH_ASSOC)["id"];

        $ins = $this->bd->prepare("insert into playlist2track(id_pl, id_track, no_piste_dans_liste) values(?,?,?)");
        $ins->bindParam(1,$plId);
        $ins->bindParam(2,$trId);
        $nb = count($pl->tracks);
        $ins->bindParam(3,$nb);
        $ins->execute();

        return true;

    }
}