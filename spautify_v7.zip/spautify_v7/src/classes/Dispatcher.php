<?php

namespace spautify;

use spautify\actions as A;

class Dispatcher {

    private ?string $action;

    function __construct(?string $action){
        $this->action = $action;
    }

    public function renderPage($html){
        echo $html;
    }

    public function run(){
        $html = "";
        $html .= '<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Document</title>
        </head>
        <body>';
        switch($this->action){
            case 'default':
                $action = new A\DefaultAction();
                $html = $action->execute();
                break;
            case 'add-playlist':
                $action = new A\AddPlaylistAction();
                $html = $action->execute();
                break;
            case 'add-track':
                $action = new A\AddPodcastTrackAction();
                $html = $action->execute();
                break;
            case 'display-playlist':
                $action = new A\DisplayPlaylistAction();
                $html = $action->execute();
                break;
            case 'add-user':
                $action = new A\AddUserAction();
                $html = $action->execute();
                break;
            case 'sign-in':
                $action = new A\SigninAction();
                $html = $action->execute();
                break;
            case 'select-playlist':
                $action = new A\SelectPlayListAction();
                $html = $action->execute();
                break;
            case 'disconnect':
                $action = new A\DisconnectAction();
                $html = $action->execute();
                break;
            default:
                $html .= "<a>erreur sur la requête</a>";
                break;

        }
        $html .= '</body>
        </html>';
        $this->renderPage($html);
    }
}