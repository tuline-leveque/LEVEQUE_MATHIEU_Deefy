<?php

namespace spautify\actions;
use spautify\repository as SR;
use spautify\audio as AD;
use PDO;

class AddPlaylistAction extends Action {
    public function execute() : string {
        $html = "";
        $emailUser = \spautify\auth\AuthnProvider::getSignedInUser();
        if ($emailUser != ""){
            if($_SERVER['REQUEST_METHOD'] == 'GET'){
                $html .= "<form method = 'POST' action ='?action=add-playlist'></br>";
                $html .= "<label for='playlist'>Nom de la playlist :</label></br>";
                $html .= "<input type='text' id='playlist_name' name='playlist_name'></br></br>";
                $html .= "<button type = 'submit'>créer</button></form>";
            } else {
                $pl = new AD\AudioList(filter_var($_POST['playlist_name'], FILTER_SANITIZE_SPECIAL_CHARS),[]);
                $_SESSION['playlist'] = serialize($pl);
                $bd = SR\SpautifyRepository::getInstance();
                $bd->savePlayList($pl);
                //chercher id user et id playlist
                $conn = $bd->getDb();

                $plQuery = $conn->prepare("select max(id) from playlist;");
                $plQuery->execute();
                $plId = $plQuery->fetch(PDO::FETCH_ASSOC)['max(id)'];

                $usrQuery = $conn->prepare("select id from user where email = ?;");
                $usrQuery->bindParam(1,unserialize($_SESSION['user'])[0]);
                $usrQuery->execute();
                $usrId = $usrQuery->fetch(PDO::FETCH_ASSOC)['id'];

                $ins = $conn->prepare("insert into user2playlist(id_user, id_pl) values (?,?);");
                $ins->bindParam(1,$usrId );
                $ins->bindParam(2,$plId);
                $ins->execute();
                $html.='<a href="?action=add-track"> ajouter une musique </a>';
            }

        } else {
            $html .= "</br><h3>Vous devez être connecté afin de créer une playlist</h3>";
            $html .= "</br><a href='?action=sign-in'>Connectez vous ici</a>";
        }
        $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';
        return $html;
    }
}