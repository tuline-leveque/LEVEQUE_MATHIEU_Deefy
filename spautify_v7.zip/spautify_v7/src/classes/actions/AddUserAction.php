<?php

namespace spautify\actions;

use spautify\exception\AuthnException;

class AddUserAction extends Action{
    public function execute() :string {
        $html = "";

        if($_SERVER['REQUEST_METHOD'] == "GET" || !isset($_POST['email'])){
            $html .= "<form method = 'POST' action ='?action=add-user'></br>";
            $html .= "<label for='email'>Email :</label></br>";
            $html .= "<input type='text' id='email' name='email'></br></br>";
            $html .="<label for='mdp'>Mot de passe :</label></br>";
            $html .= "<input type='text' id='mdp' name='mdp'></br></br>";
            $html .= "<label for='mdp2'>Veuillez répéter votre mot de passe :</label></br>";
            $html .= "<input type='text' id='mdp2' name='mdp2'></br></br>";
            $html .= "<button type = 'submit'>s'inscrire</button></form>";
            $html .= "<a href='?action=sign-in'>Vous avez déjà un compte ? Connectez vous !</a>";
            $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';
        } else {
            if ($_POST['mdp'] != $_POST['mdp2']){
                $html .= "</br><a>Vous devez indiquer deux fois le même mot de passe</a></br>";
                $html .= "</br><a href='?action=add-user'>J'ai compris</a>";
                return $html;
            }
            try{
                \spautify\auth\AuthnProvider::register($_POST['email'], $_POST['mdp']);
                $_SESSION['user'] = serialize(array($_POST['email'], $_POST['mdp']));
                unset($_SESSION['playlist']);
                $html .= "<a>Enregistrement réussi. Bonjour {$_POST['email']} !</a>";
            } catch (Exception $e){
                $html .= "<a>{$e->getMessage()}</a>";
            } catch (AuthnException $e1) {
                $html .= "<a>{$e1->getMessage()}</a>";
            }
            $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';

        }

        return $html;
    }
}