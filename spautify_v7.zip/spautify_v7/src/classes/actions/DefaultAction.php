<?php 

namespace spautify\actions;

class DefaultAction extends Action{
    public function execute() : string {

        $html = "<h1>Bienvenue sur Spautify</h1>";

        $user = \spautify\auth\AuthnProvider::getSignedInUser();
        if ($user == "") {
            $html .= "<b>Connecté en tant qu'invité</b></br></br>";
        } else {
            $emailUser = unserialize($user)[0];
            $html .= "<b>Connecté en tant que {$emailUser}</b></br></br>";
        }

        $html .= '<a href="?action=add-track"> ajouter une musique </a></br>';
        $html .= '<a href="?action=add-playlist"> créer une playlist </a></br>';
        $html .= '<a href="?action=display-playlist"> afficher une playlist </a></br>';
        $html .= '<a href="?action=select-playlist"> afficher toutes les playlists </a></br>';
        $html .= '<a href="?action=add-user"> créer utilisateur </a></br>';
        $html .= '<a href="?action=sign-in"> se connecter </a></br>';
        $html .= '<a href="?action=disconnect"> se déconnecter </a></br>';
        return $html;
    }
}