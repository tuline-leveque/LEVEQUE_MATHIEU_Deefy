<?php

namespace spautify\actions;

class DisconnectAction extends Action {
    public function execute() : string {
        $html = "<a>Vous avez été déconnecté de spautify</a></br>";
        $html .= "<a href ='?action=default'>retour au menu principal</a>";

        unset($_SESSION['user']);
        unset($_SESSION['playlist']);

        return $html;
    }
}