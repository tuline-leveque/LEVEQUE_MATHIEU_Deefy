<?php

namespace spautify\actions;

use PDO;

class SelectPlayListAction extends Action{
    public function execute() :string {
        $html = "";
        $user = \spautify\auth\AuthnProvider::getSignedInUser();
        if($user == ""){
            return "<a>Veuillez vous connecter avant de pouvoir sélectionner des playlists</a></br><a href='?action=default'>retour au menu principal</a>";
        }
        if($_SERVER['REQUEST_METHOD'] == "GET" || ! isset($_POST['plid'])){

            $html .= "<form method = 'POST' action ='?action=select-playlist'></br>";
            $nb = 0;

            $bd = \spautify\repository\SpautifyRepository::getInstance();
            foreach($bd->getAllPlaylists() as $pl){
                $html .= "<input type='radio' id='plList' name='plid' value='{$pl['id']}'><a>{$pl['nom']}</a></br></br>";
                $nb ++;
            }

            if ($nb == 0) {
                $html .= '<b>Aucune playlist existante</b>';
            } else {
                $html .= "<input type='submit' value = 'choisir cette playlist'>";
            }

            $html .= "</form>";
            $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';
            
        } else {
            $bd = \spautify\repository\SpautifyRepository::getInstance()->getDb();
            $plQuery = $bd->prepare("select nom from playlist where id = ? ;");
            $plQuery->bindParam(1,$_POST['plid']);
            $plQuery->execute();

            $plName = $plQuery->fetch(PDO::FETCH_ASSOC)['nom'];

            $trQuery = $bd->prepare("SELECT track.*,playlist2track.no_piste_dans_liste FROM `track` inner join playlist2track on playlist2track.id_track = track.id inner join playlist on playlist.id = playlist2track.id_pl where playlist.id = ?;");
            $trQuery->bindParam(1,$_POST['plid']);
            $trQuery->execute();

            $tracks = [];

            foreach($trQuery->fetchAll(PDO::FETCH_ASSOC) as $t){
                if($t['type'] == "A"){
                    array_push($tracks, new \spautify\audio\AlbumTrack($t['titre'], $t['artiste_album'], $t['annee_album'], $t['genre'], (int)($t['duree']), $t['filename'], $t['no_piste_dans_liste'], $t['titre_album']));
                } else {
                    array_push($tracks, new \spautify\audio\PodcastTrack($t['titre'], $t['auteur_podcast'], $t['date_posdcast'], $t['genre'], (int)($t['duree']), $t['filename']));
                }
            }

            $pl = new \spautify\audio\PlayList($plName, $tracks);
            $_SESSION['playlist'] = serialize($pl);
            $html .= "<a>playlist sélectionnée</a></br>";
            $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';

        }
        return $html;

    }

}