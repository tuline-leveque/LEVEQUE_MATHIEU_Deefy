<?php

namespace spautify\actions;

use spautify\exception\AuthnException;

class SigninAction extends Action{
    public function execute() :string {
        $html = "";

        if($_SERVER['REQUEST_METHOD'] == "GET"){
            $html .= "<form method = 'POST' action ='?action=sign-in'></br>";
            $html .= "<label for='email'>Email :</label></br>";
            $html .= "<input type='text' id='email' name='email'></br></br>";
            $html .="<label for='mdp'>Mot de passe :</label></br>";
            $html .= "<input type='text' id='mdp' name='mdp'></br></br>";
            $html .= "<button type = 'submit'>Se connecter</button></form>";
            $html .= "<a href='?action=add-user'>Pas encore de compte ? Créez en un maintenant !</a>";
            $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';
        } else {
            try{
                \spautify\auth\AuthnProvider::signin($_POST['email'], $_POST['mdp']);
                $_SESSION['user'] = serialize(array($_POST['email'], $_POST['mdp']));
                unset($_SESSION['playlist']);
                $html .= "<a>Connexion réussie, bonjour {$_POST['email']} !</a></br>";
            } catch (Exception $e){
                $html .= "<a>email ou mot de passe incorrect</a>";
                $html .= "</br></br><a href='?action=sign-in'>Réessayer</a>";
            } catch (AuthnException $e2) {
                $html .= "<a>email ou mot de passe incorrect</a>";
                $html .= "</br></br><a href='?action=sign-in'>Réessayer</a>";
            }
            $html .= '</br></br><a href="?action=default"> Retourner au menu </a>';

        }

        return $html;
    }
}


