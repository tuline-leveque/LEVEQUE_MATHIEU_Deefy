<?php

namespace spautify\audio;

use spautify\exception\ArgumentException;

class AudioList {

    public string $name;
    public int $duration;
    public array $tracks;

    public function __construct(string $name, array $tracks = []){
        $this->name = $name;
        $this->tracks = $tracks;
        $this->duration = 0;

        foreach($this->tracks as $arr){
            $this->duration += $arr->durationSec;
        }

    }

    public function add(AudioTrack $a){
        $this->tracks[sizeof($this->tracks)] = $a;
    }

    /**
     * @throws ArgumentException
     */
    public function __get(string $attr){
        if(property_exists($this,$attr)){
            return $this->$attr;
        } else {
            throw new \spautify\exception\ArgumentException("attribut $attr inexistant");
        }
    }
}