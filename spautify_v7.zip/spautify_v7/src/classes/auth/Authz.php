<?php

namespace spautify\auth;

use PDO;
use spautify\exception\AuthnException;

class Authz {

    public static function checkRole($rl) {
        if( ! isset($_SESSION['user'])){
            
            return false;
        } else {
            $bd = \spautify\repository\SpautifyRepository::getInstance()->getDb();

            $rlQuery = $bd->prepare("select role from user where email = ? ;");
            $rlQuery->bindparam(1,unserialize($_SESSION['user'])[0]);
            $rlQuery->execute();
            $bdRl = $rlQuery->fetch(PDO::FETCH_ASSOC)['role'];

            return $bdRl == $rl;

        }
        
    }

    public static function checkPlayListOwner($pl){
        if( checkRole(100)){
            return true;
        } else {
            $bd = \spautify\repository\SpautifyRepository::getInstance()->geDb();

            $plQuery = $bd->prepare("select id from playlist  where nom = ? ;");
            $plQuery->bindParam(1,$pl->name);
            $plQuery->execute();
            $plId = $plQuery->fetch(PDO::FETCH_ASSOC)['id'];

            $usrQuery = $bd->prepare("select id from user  where email = ? ;");
            $usrQuery->bindParam(1,unserialize($_SESSION['user'])[0]);
            $usrQuery->execute();
            $usrId = $plQuery->fetch(PDO::FETCH_ASSOC)['id'];

            $checkQuery = $bd->prepare("select * from playlist2user where pl_id = ? and user_id = ? ;");
            $checkQuery->bindParam(1,$plId);
            $checkQuery->bindParam(1,$usrId);
            $checkQuery->execute();

            $res = $checkQuery->fetchAll(PDO::FETCH_ASSOC);

            return sizeof($res) > 0;
        }
    }
}