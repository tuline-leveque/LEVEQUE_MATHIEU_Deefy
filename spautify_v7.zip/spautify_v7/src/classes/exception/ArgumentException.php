<?php
namespace spautify\exception;
class ArgumentException extends  \Exception{}